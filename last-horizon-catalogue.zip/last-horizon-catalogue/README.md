# The Last Horizon — Le Catalogue (Boutique du Système) — v2

Le Catalogue livré avec **8 121 entrées** (compétences, titres, armes, armures, véhicules, compagnons, propriétés, objets), propulsé par le moteur **Boutique** : tout est éditable.

## Installation
`https://github.com/blendbastien/catalogue/releases/latest/download/module.json` — la mise à jour depuis la 1.x conserve niveau de boutique, saison, correspondance CSB.

## Nouveautés 2.0.0
- Moteur Boutique complet : mode **ÉDITION** (créer / modifier / dupliquer / supprimer des articles, sélection multiple, déplacement de catégorie, changements groupés), arbre éditable (catégories, sous-catégories, types : renommer, icône, famille, déplacer, supprimer), 187 icônes vectorielles, **CONFIG** (nom, monnaie, icône, 5 thèmes, rangs, raretés, éléments, mondes, époques, saisons, niveaux, roulette, bulletins), **DONNÉES** (sauvegarde / import / export JSON et CSV).
- Vos modifications sont enregistrées en **delta** par rapport au contenu livré : le monde ne stocke que ce que vous avez changé ; les mises à jour du module n'écrasent pas vos éditions.
- **Recherches quotidiennes limitées** : chaque joueur dispose de N recherches par jour dans la barre de recherche (validées avec Entrée ; effacer la recherche est gratuit). Réglage du nombre dans les options du module ; bouton **RECHERCHES** (MJ) pour voir les compteurs, accorder des recherches bonus (+1 / +5, permanentes) ou remettre un joueur à zéro. Le MJ n'est jamais limité ; le système peut être désactivé.
- Stock décrémenté à l'achat, fenêtre d'achat stylisée, chat optionnel, détection automatique des templates CSB.

## Mise à jour
Release GitHub avec exactement `module.json` et `last-horizon-catalogue.zip`.
