/* The Last Horizon — Le Catalogue (Boutique du Système) — Foundry VTT v12/v13 — moteur Boutique + contenu livré */
const MOD = "last-horizon-catalogue";
const BASE_URL = `modules/${MOD}/data/catalogue.json`;
const { ApplicationV2 } = foundry.applications.api;

/* ───────────────── Réglages ───────────────── */
const MAP_DEFAULT = {
  itemType: "equippableItem", templateName: "",
  keyName: "", keyRang: "rang", keyRarete: "rarete", keyType: "type", keyGold: "gold", keyQuantite: "quantite",
  keyDescription: "description", keyLore: "lore", keyNiveau: "niveau", keyElement: "element", keyCategorie: "", keyRangNum: "",
  actorGoldPath: "system.props.gold", deduct: true
};
class MappingConfig extends FormApplication {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions, { id: "bq-map", title: "Boutique — Correspondance CSB", template: `modules/${MOD}/templates/mapping.hbs`, width: 560, classes: ["bq-map-form"] }); }
  getData() { return { m: foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping")) }; }
  async _updateObject(_ev, data) { await game.settings.set(MOD, "mapping", foundry.utils.expandObject(data).m); ui.notifications.info("Correspondance CSB enregistrée."); }
}

Hooks.once("init", () => {
  game.settings.register(MOD, "delta", { scope: "world", config: false, type: String, default: "" });
  game.settings.register(MOD, "searchEnabled", { name: "Recherches quotidiennes limitées", hint: "Chaque joueur dispose d'un nombre de recherches (barre de recherche) par jour. Le MJ n'est jamais limité.", scope: "world", config: true, type: Boolean, default: true, onChange: () => pushState() });
  game.settings.register(MOD, "searchQuota", { name: "Recherches par jour et par joueur", scope: "world", config: true, type: Number, range: { min: 0, max: 50, step: 1 }, default: 3, onChange: () => pushState() });
  game.settings.registerMenu(MOD, "searchMenu", { name: "Quota de recherches des joueurs", label: "Gérer", hint: "Voir les recherches consommées aujourd'hui, accorder des recherches supplémentaires, remettre à zéro.", icon: "fa-solid fa-magnifying-glass", type: SearchAdmin, restricted: true });
  game.settings.register(MOD, "shopLv", { name: "Niveau de la Boutique", hint: "Ce que les joueurs peuvent voir et acheter. Modifiable aussi depuis la fenêtre (MJ).", scope: "world", config: true, type: Number, range: { min: 1, max: 30, step: 1 }, default: 1, onChange: () => pushState() });
  game.settings.register(MOD, "season", { scope: "world", config: false, type: String, default: "" });
  game.settings.register(MOD, "playersCanOpen", { name: "Les joueurs peuvent ouvrir la Boutique", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "playersCanBuy", { name: "Les joueurs peuvent acheter", hint: "Sinon seul le MJ peut créer les objets.", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "chatOnBuy", { name: "Message dans le chat à chaque achat", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "stockDecrement", { name: "Décrémenter le stock à l'achat", hint: "Un article dont le stock est géré perd un exemplaire à chaque achat.", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "windowWidth", { name: "Largeur de la fenêtre", scope: "client", config: true, type: Number, default: 1500 });
  game.settings.register(MOD, "windowHeight", { name: "Hauteur de la fenêtre", scope: "client", config: true, type: Number, default: 900 });
  game.settings.register(MOD, "mapping", { scope: "world", config: false, type: Object, default: MAP_DEFAULT });
  game.settings.registerMenu(MOD, "mappingMenu", { name: "Correspondance des champs CSB", label: "Configurer", hint: "Clés des propriétés Custom System Builder utilisées à l'achat et à l'import.", icon: "fa-solid fa-sliders", type: MappingConfig, restricted: true });
  game.settings.registerMenu(MOD, "importMenu", { name: "Importer le Catalogue en compendium", label: "Importer", hint: "Crée des compendiums d'Items (un par type) à partir des articles de la Boutique.", icon: "fa-solid fa-boxes-stacked", type: ImportDialog, restricted: true });
  game.modules.get(MOD).api = { open: openBoutique, buy: buyEntry, importCompendium, getDB, setDB, loadBase, searchState, grantSearches, templates, templateKeys, diagnose: () => templates().map(t => ({ template: t.name, keys: templateKeys(t).map(k => k.key + " (" + k.label + ")") })) };
});

/* ───────────────── Base de données (réglage du monde) ───────────────── */
const CFG_KEYS = ["meta", "ranks", "rars", "elems", "worlds", "epochs", "seasons", "levels", "types", "cats", "ticker"];
let _base = null;
async function loadBase() { if (!_base) _base = await (await fetch(BASE_URL)).json(); return _base; }
Hooks.once("ready", () => { loadBase().catch(e => console.error(MOD, e)); });
function getDelta() { try { const s = game.settings.get(MOD, "delta"); return s ? JSON.parse(s) : null; } catch (e) { console.error(MOD, "delta illisible", e); return null; } }
/* base + delta → base fusionnée (synchrone si la base est déjà chargée) */
function getDB() {
  if (!_base) return null;
  const d = foundry.utils.deepClone(_base); const delta = getDelta();
  if (delta) { if (delta.cfg) for (const k in delta.cfg) if (CFG_KEYS.includes(k)) d[k] = delta.cfg[k]; const del = new Set(delta.del || []); if (del.size) d.items = d.items.filter(e => !del.has(e.id)); if (delta.items) { const idx = new Map(d.items.map((e, i) => [e.id, i])); for (const id in delta.items) { const e = delta.items[id]; if (idx.has(id)) d.items[idx.get(id)] = e; else d.items.push(e); } } }
  return d;
}
async function getDBAsync() { await loadBase(); return getDB(); }
async function setDB(delta) { if (!game.user.isGM) return ui.notifications.warn("Seul le MJ peut modifier le Catalogue."); await game.settings.set(MOD, "delta", JSON.stringify(delta)); }
/* met à jour un article dans le delta (stock…) */
async function patchItem(id, fn) { const db = await getDBAsync(); const it = db.items.find(x => x.id === id); if (!it) return null; fn(it); const delta = getDelta() || { v: 2, cfg: {}, items: {}, del: [] }; delta.items = delta.items || {}; delta.items[id] = it; await setDB(delta); return it; }
const typeName = (db, t) => (db?.types || []).find(x => x.id === t)?.name || t;
const rankIndex = (db, r) => Math.max(0, (db?.ranks || []).findIndex(x => x.id === r));
const iconPath = k => k && /^[a-z0-9_]+$/.test(k) ? `modules/${MOD}/icons/${k}.svg` : `modules/${MOD}/icons/box.svg`;

/* ───────────────── Fenêtre ───────────────── */
class CatalogueApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "lh-catalogue", classes: ["bq-frame"], window: { title: "Le Catalogue — Boutique du Système", icon: "fa-solid fa-store", resizable: true, minimizable: true }, position: { width: 1500, height: 900 } };
  async _prepareContext() { return {}; }
  async _renderHTML() { const f = document.createElement("iframe"); f.className = "bq-iframe"; f.src = `modules/${MOD}/app/catalogue.html`; this.frame = f; return f; }
  _replaceHTML(result, content) { content.replaceChildren(result); }
}
let app = null;
function openBoutique() {
  if (!app) app = new CatalogueApp({ position: { width: game.settings.get(MOD, "windowWidth") || 1500, height: game.settings.get(MOD, "windowHeight") || 900 } });
  const db = getDB(); if (db?.meta?.name && app.options.window) app.options.window.title = db.meta.name + (db.meta.sub ? " — " + db.meta.sub : "");
  app.render({ force: true }); return app;
}
function stateMsg(type, withDb) { const m = { type, shopLv: game.settings.get(MOD, "shopLv"), season: game.settings.get(MOD, "season"), isGM: game.user.isGM, hideExport: !game.user.isGM, search: searchState(game.user), searchAdmin: true }; if (withDb) { m.baseUrl = BASE_URL; m.delta = getDelta(); } return m; }
function initFrame(win) { win.postMessage(stateMsg("bq-init", true), "*"); }
function pushState(withDb) { app?.frame?.contentWindow?.postMessage(stateMsg("bq-state", !!withDb), "*"); }

window.addEventListener("message", async ev => {
  const m = ev.data || {}; if (!m || typeof m.type !== "string" || !m.type.startsWith("bq-")) return;
  const win = ev.source; if (win !== app?.frame?.contentWindow) return;   /* ignore les autres modules (Boutique) */
  if (m.type === "bq-ready") initFrame(win);
  else if (m.type === "bq-setlv") { if (game.user.isGM) await game.settings.set(MOD, "shopLv", Math.max(1, Math.min(30, m.shopLv))); else initFrame(win); }
  else if (m.type === "bq-setseason") { if (game.user.isGM) await game.settings.set(MOD, "season", m.season || ""); else initFrame(win); }
  else if (m.type === "bq-save") { if (!game.user.isGM) return; await setDB(m.delta); win.postMessage({ type: "bq-saved" }, "*"); if (app?.options?.window && m.db?.meta?.name) { app.options.window.title = m.db.meta.name; app.render({ force: false }); } }
  else if (m.type === "bq-search") { const r = await consumeSearch(m.q); win.postMessage(r, "*"); }
  else if (m.type === "bq-searchadmin") { if (game.user.isGM) new SearchAdmin().render(true); }
  else if (m.type === "bq-buy") { const r = await buyEntry(m.entry, m); if (r) win.postMessage({ type: "bq-bought", id: m.entry.id, name: r.item.name, actor: r.actor.name, stockLeft: r.stockLeft }, "*"); }
});
Hooks.on("updateSetting", (s, changes, opts, userId) => {
  if (s.key === `${MOD}.shopLv` || s.key === `${MOD}.season`) pushState(false);
  if (s.key === `${MOD}.delta` && userId !== game.user.id) pushState(true);
  if (s.key === `${MOD}.searchEnabled` || s.key === `${MOD}.searchQuota`) pushState(false);   /* l'auteur a déjà la base à jour */
});

/* ───────────────── Achat ───────────────── */
function targetActor() { const tok = canvas?.tokens?.controlled?.[0]; if (tok?.actor) return tok.actor; if (game.user.character) return game.user.character; return null; }
function fmtG(v, cur) { return Math.round(v || 0).toLocaleString("fr-FR") + " " + (cur || "G"); }
async function buyEntry(e, extra = {}) {
  const db = (await getDBAsync()) || {}; const cur = db.meta?.cur || "G";
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanBuy")) return ui.notifications.warn("Les achats sont réservés au MJ.");
  if (Math.min(e.reqShop || 1, db.levels?.length || 99) > game.settings.get(MOD, "shopLv") && !game.user.isGM) return ui.notifications.warn("Niveau de boutique insuffisant.");
  if (e.season && e.season !== game.settings.get(MOD, "season") && !game.user.isGM) return ui.notifications.warn(`Hors saison (${e.season}).`);
  const live = (db.items || []).find(x => x.id === e.id) || e;
  if (live.stock === 0) return ui.notifications.warn("Rupture de stock.");
  const actor = targetActor(); if (!actor) return ui.notifications.warn("Sélectionne un token ou assigne-toi un personnage.");
  if (!actor.isOwner) return ui.notifications.warn("Tu ne possèdes pas ce personnage.");
  const M = foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping"));
  const price = live.price || 0; const tn = extra.typeName || typeName(db, live.t);
  const rc = (db.ranks || []).find(r => r.id === live.rang)?.color || "#fff";
  const cur0 = Number(foundry.utils.getProperty(actor, M.actorGoldPath));
  const content = `<div class="bq-buywin" style="--rc:${rc}">
    <div class="bq-bw-head"><div class="bq-bw-badge">${esc(live.rang)}</div><div><div class="bq-bw-sys">[ FENÊTRE SYSTÈME // ACHAT ]</div><div class="bq-bw-name">${esc(live.n)}</div><div class="bq-bw-meta"><span>${esc(live.rar)}</span><span>${esc(tn)}${live.sub ? " · " + esc(live.sub) : ""}</span>${live.elem ? `<span>${esc(live.elem)}</span>` : ""}${live.season ? `<span class="s">✦ ${esc(live.season)}</span>` : ""}</div></div></div>
    <div class="bq-bw-desc">${esc(live.desc)}</div>
    <div class="bq-bw-row"><span>PRIX</span><b class="g">${fmtG(price, cur)}</b></div>
    <div class="bq-bw-row"><span>ACQUÉREUR</span><b>${esc(actor.name)}</b></div>
    ${live.stock != null && live.stock !== "" ? `<div class="bq-bw-row"><span>STOCK</span><b>${live.stock}</b></div>` : ""}
    ${M.deduct && price ? `<div class="bq-bw-row"><span>PORTEFEUILLE</span><b class="${Number.isFinite(cur0) && cur0 < price ? "bad" : ""}">${Number.isFinite(cur0) ? fmtG(cur0, cur) + " → " + fmtG(cur0 - price, cur) : "—"}</b></div>` : ""}
    <div class="bq-bw-foot">Le Système ne pratique aucun remboursement.</div></div>`;
  const ok = await new Promise(res => new Dialog({ title: db.meta?.name || "Boutique", content, buttons: { yes: { icon: '<i class="fa-solid fa-gem"></i>', label: "Acheter", callback: () => res(true) }, no: { icon: '<i class="fa-solid fa-xmark"></i>', label: "Annuler", callback: () => res(false) } }, default: "yes", close: () => res(false) }, { classes: ["dialog", "bq-dialog"], width: 460 }).render(true));
  if (!ok) return null;
  if (M.deduct && price) {
    const c = Number(foundry.utils.getProperty(actor, M.actorGoldPath));
    if (Number.isFinite(c)) {
      if (c < price) { if (!game.user.isGM) return ui.notifications.error(`Fonds insuffisants : ${fmtG(c, cur)} disponibles.`); ui.notifications.warn(`Fonds insuffisants (${fmtG(c, cur)}), achat forcé par le MJ.`); }
      await actor.update({ [M.actorGoldPath]: c - price });
    } else ui.notifications.warn(`Portefeuille introuvable (${M.actorGoldPath}) — objet créé sans débit.`);
  }
  const data = await itemData(live, M, db, extra.icon);
  const [item] = await actor.createEmbeddedDocuments("Item", [data]);
  ui.notifications.info(`${live.n} ajouté à ${actor.name}.`);
  let stockLeft = null;
  if (game.settings.get(MOD, "stockDecrement") && live.stock != null && live.stock !== "" && db.items) {
    const it = db.items.find(x => x.id === live.id); if (it && it.stock > 0) { stockLeft = it.stock - 1; if (game.user.isGM) await patchItem(live.id, x => { x.stock = Math.max(0, x.stock - 1); }); else game.socket?.emit(`module.${MOD}`, { type: "stock", id: live.id }); }
  }
  if (game.settings.get(MOD, "chatOnBuy")) ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: `<div class="bq-chat"><b>◆ ${esc(db.meta?.name || "Boutique")}</b><br>${esc(actor.name)} acquiert <b>${esc(live.n)}</b> (rang ${esc(live.rang)} · ${esc(live.rar)}) pour ${fmtG(price, cur)}.</div>` });
  return { item, actor, stockLeft };
}
/* décrément de stock demandé par un joueur : exécuté par le premier MJ connecté */
Hooks.once("ready", () => { game.socket?.on(`module.${MOD}`, async m => { if (m?.type !== "stock" || !game.user.isGM || game.users.activeGM?.id !== game.user.id) return; const it = await patchItem(m.id, x => { x.stock = Math.max(0, x.stock - 1); }); if (it) pushState(true); }); });
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

/* Construit les données d'Item (CSB si possible, sinon générique) */
const TPL_RX = { weapon: /arme|weapon/i, armor: /armure|armor|équipement|equipement/i, accessory: /accessoire|bijou/i, skill: /comp[ée]tence|skill|sort|capacit/i, title: /titre|title/i, vehicle: /v[ée]hicule|vehicle|monture/i, companion: /compagnon|familier|pet|cr[ée]ature/i, property: /propri[ée]t|maison|bien|domaine/i, item: /objet|item|consommable|loot|divers|inventaire/i };
function templates() { return game.items.filter(i => i.type === "_equippableItemTemplate"); }
function findTemplate(M, e, db) {
  const tpls = templates(); if (!tpls.length) return false;
  if (M.templateName) { const t = tpls.find(t => t.name === M.templateName); if (t) return t; }
  const tryRx = rx => tpls.find(t => rx.test(t.name));
  if (e) {
    if (e.cat && /accessoire|bijou/i.test(e.cat)) { const t = tryRx(TPL_RX.accessory); if (t) return t; }
    const tn = typeName(db, e.t);
    const t = tryRx(TPL_RX[e.t] || new RegExp(tn.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i")); if (t) return t;
    const g = tryRx(TPL_RX.item); if (g) return g;
  }
  return tpls[0];
}
function templateKeys(tpl) {
  const out = []; const walk = o => { if (!o || typeof o !== "object") return; if (Array.isArray(o)) return o.forEach(walk); if (typeof o.key === "string" && o.key) out.push({ key: o.key, label: String(o.label || o.title || o.key), type: o.type || "" }); for (const k of ["contents", "rows", "cols", "columns", "children", "items", "body", "header", "tabs", "content"]) if (o[k]) walk(o[k]); };
  walk(tpl.system?.header); walk(tpl.system?.body); return out;
}
const KEY_RX = { keyRang: /^rang|rank/i, keyRangNum: /rang.?num|rank.?num/i, keyRarete: /raret|rarity/i, keyType: /^type|categorie|cat[ée]gorie/i, keyCategorie: /cat[ée]gorie/i, keyElement: /[ée]l[ée]ment/i, keyGold: /gold|^or$|prix|price|co[uû]t|monnaie/i, keyQuantite: /quantit|qte|qty|nombre/i, keyNiveau: /niveau|level|^lv/i, keyDescription: /descr|effet|effect/i, keyLore: /lore|histoire|fluff/i, keyName: /^nom$|^name$/i };
function autoKeys(tpl, M) {
  const ks = templateKeys(tpl); const res = { ...M };
  for (const [field, rx] of Object.entries(KEY_RX)) {
    if (res[field] && ks.some(k => k.key === res[field])) continue;
    const hit = ks.find(k => rx.test(k.key)) || ks.find(k => rx.test(k.label));
    res[field] = hit ? hit.key : (ks.some(k => k.key === res[field]) ? res[field] : "");
  }
  return res;
}
async function itemData(e, M0, db, icon) { let M = M0; db = db || getDB() || {};
  const lvl = e.lv ? 1 : null;
  const desc = `<p>${esc(e.desc)}</p>${e.lore ? `<p><i>${esc(e.lore)}</i></p>` : ""}${e.evo ? `<p><b>Évolution :</b> ${esc(e.evo)}</p>` : ""}${e.cond ? `<p><b>Condition :</b> ${esc(e.cond)}</p>` : ""}`;
  const ic = icon || e.icon || (db.cats || []).find(c => c.type === e.t && c.name === e.cat)?.subs?.find(s => s.name === e.sub)?.icon || (db.cats || []).find(c => c.type === e.t && c.name === e.cat)?.icon || (db.types || []).find(t => t.id === e.t)?.icon;
  const base = { name: e.n, img: iconPath(ic), flags: { [MOD]: { id: e.id, t: e.t, cat: e.cat, sub: e.sub, rang: e.rang, rar: e.rar, price: e.price, elem: e.elem, origin: e.origin } } };
  const csb = game.system.id === "custom-system-builder";
  if (csb) {
    const tpl = findTemplate(M, e, db);
    if (tpl) M = autoKeys(tpl, M);
    const props = {};
    const set = (k, v) => { if (k && v !== undefined && v !== null && v !== "") props[k] = v; };
    set(M.keyName, e.n); set(M.keyRang, e.rang); set(M.keyRarete, e.rar); set(M.keyType, e.sub || e.cat); set(M.keyCategorie, e.cat);
    set(M.keyGold, e.price || 0); set(M.keyQuantite, 1); set(M.keyDescription, e.desc); set(M.keyLore, e.lore || ""); set(M.keyNiveau, lvl); set(M.keyElement, e.elem || "");
    set(M.keyRangNum, rankIndex(db, e.rang) + 1);
    const sys = { props, description: desc };
    if (tpl) sys.template = tpl.id; else ui.notifications.warn("Aucun template d'objet CSB trouvé dans ce monde : objet créé sans template.");
    return { ...base, type: M.itemType || "equippableItem", system: sys };
  }
  const types = Object.keys(game.documentTypes?.Item || CONFIG.Item.typeLabels || {}).filter(t => t !== "base");
  return { ...base, type: types[0] || "base", system: { description: desc } };
}

/* ───────────────── Import compendium ───────────────── */
class ImportDialog extends FormApplication {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions, { id: "bq-import", title: "Importer la Boutique en compendium", template: `modules/${MOD}/templates/import.hbs`, width: 460 }); }
  getData() { const db = getDB() || { types: [], items: [] }; /* base chargée au ready */ return { types: db.types.map(t => ({ k: t.id, v: t.label, n: db.items.filter(e => e.t === t.id).length })).filter(t => t.n) }; }
  async _updateObject(_ev, data) { const types = Object.entries(data).filter(([k, v]) => v).map(([k]) => k); if (!types.length) return ui.notifications.warn("Choisis au moins un type."); await importCompendium(types); }
}
async function importCompendium(types) {
  const db = await getDBAsync(); if (!db) return ui.notifications.warn("Le Catalogue est introuvable.");
  const M = foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping"));
  for (const t of types) {
    const T = db.types.find(x => x.id === t); const rows = db.items.filter(e => e.t === t); if (!rows.length) continue;
    const name = `lh-${t.replace(/[^a-z0-9_-]/gi, "_")}`; const label = `${db.meta?.name || "Boutique"} — ${T?.label || t}`;
    let pack = game.packs.get(`world.${name}`);
    if (!pack) pack = await CompendiumCollection.createCompendium({ label, name, type: "Item", package: "world" });
    await pack.configure({ locked: false });
    const existing = new Set((await pack.getIndex({ fields: ["flags"] })).map(i => i.flags?.[MOD]?.id).filter(Boolean));
    const todo = rows.filter(e => !existing.has(e.id));
    ui.notifications.info(`${label} : ${todo.length} article(s) à importer…`);
    const docs = []; for (const e of todo) docs.push(await itemData(e, M, db));
    for (let i = 0; i < docs.length; i += 200) { await Item.createDocuments(docs.slice(i, i + 200), { pack: pack.collection, keepId: false }); ui.notifications.info(`${label} : ${Math.min(i + 200, docs.length)} / ${docs.length}`); }
    await pack.configure({ locked: true });
  }
  ui.notifications.info("Import terminé.");
}

/* ───────────────── Boutons ───────────────── */
Hooks.on("getSceneControlButtons", controls => {
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanOpen")) return;
  const tool = { name: "lh-catalogue", title: "Le Catalogue — Boutique du Système", icon: "fa-solid fa-store", button: true, order: 99, onChange: () => openBoutique(), onClick: () => openBoutique() };
  if (Array.isArray(controls)) { const c = controls.find(c => c.name === "notes") || controls[0]; c.tools.push(tool); }
  else { const c = controls.notes || controls.tokens; if (c) c.tools["bq-boutique"] = tool; }
});
Hooks.on("renderItemDirectory", (dir, html) => {
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanOpen")) return;
  const root = html instanceof HTMLElement ? html : html[0]; if (root.querySelector(".bq-cat-btn")) return;
  const db = getDB(); const btn = document.createElement("button"); btn.className = "bq-cat-btn"; btn.innerHTML = `<i class="fa-solid fa-store"></i> ${esc(db?.meta?.name || "Le Catalogue")}`; btn.addEventListener("click", openBoutique);
  (root.querySelector(".directory-header") || root).appendChild(btn);
});

/* ───────────────── Recherches quotidiennes ───────────────── */
const today = () => new Date().toISOString().slice(0, 10);
function searchState(user) {
  const enabled = game.settings.get(MOD, "searchEnabled"); const quota = game.settings.get(MOD, "searchQuota");
  const f = user.getFlag(MOD, "search") || {}; const used = f.date === today() ? (f.used || 0) : 0; const extra = f.extra || 0;
  const remaining = user.isGM ? Infinity : Math.max(0, quota + extra - used);
  return { enabled: enabled && !user.isGM, quota: quota + extra, used, extra, remaining: user.isGM ? 9999 : remaining };
}
async function consumeSearch(q) {
  const st = searchState(game.user);
  if (!st.enabled) return { type: "bq-searchok", q, search: st };
  if (st.remaining <= 0) return { type: "bq-searchdeny", search: st };
  const f = game.user.getFlag(MOD, "search") || {}; const used = (f.date === today() ? (f.used || 0) : 0) + 1;
  await game.user.setFlag(MOD, "search", { date: today(), used, extra: f.extra || 0, last: q });
  return { type: "bq-searchok", q, search: searchState(game.user) };
}
async function grantSearches(user, n) { if (!game.user.isGM) return; const f = user.getFlag(MOD, "search") || {}; await user.setFlag(MOD, "search", { date: f.date || today(), used: f.used || 0, extra: (f.extra || 0) + n, last: f.last || "" }); }
async function resetSearches(user) { if (!game.user.isGM) return; const f = user.getFlag(MOD, "search") || {}; await user.setFlag(MOD, "search", { date: today(), used: 0, extra: f.extra || 0, last: f.last || "" }); }
Hooks.on("updateUser", (user) => { if (user.id === game.user.id) pushState(false); if (game.user.isGM) Object.values(ui.windows).forEach(w => { if (w instanceof SearchAdmin) w.render(false); }); });
class SearchAdmin extends FormApplication {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions, { id: "lh-search-admin", title: "Catalogue — Recherches quotidiennes des joueurs", template: `modules/${MOD}/templates/search.hbs`, width: 560, height: "auto", classes: ["lh-search-admin"] }); }
  getData() { return { enabled: game.settings.get(MOD, "searchEnabled"), quota: game.settings.get(MOD, "searchQuota"), today: today(), users: game.users.filter(u => !u.isGM).map(u => { const st = searchState(u); const f = u.getFlag(MOD, "search") || {}; return { id: u.id, name: u.name, color: u.color, active: u.active, used: st.used, extra: st.extra, remaining: st.remaining, total: st.quota, last: f.date === today() ? (f.last || "") : "" }; }) }; }
  activateListeners(html) { super.activateListeners(html); const root = html[0] || html;
    root.querySelectorAll("[data-act]").forEach(b => b.addEventListener("click", async ev => { ev.preventDefault(); const u = game.users.get(b.dataset.user); const act = b.dataset.act; if (act === "plus") await grantSearches(u, Number(b.dataset.n)); if (act === "minus") await grantSearches(u, -Number(b.dataset.n)); if (act === "reset") await resetSearches(u); if (act === "clearExtra") { const f = u.getFlag(MOD, "search") || {}; await u.setFlag(MOD, "search", { ...f, extra: 0 }); } this.render(false); }));
    root.querySelector("[data-all-reset]")?.addEventListener("click", async ev => { ev.preventDefault(); for (const u of game.users.filter(u => !u.isGM)) await resetSearches(u); this.render(false); });
  }
  async _updateObject(_ev, data) { await game.settings.set(MOD, "searchEnabled", !!data.enabled); await game.settings.set(MOD, "searchQuota", Math.max(0, Number(data.quota) || 0)); ui.notifications.info("Quota de recherches enregistré."); }
}
