/* The Last Horizon — Le Catalogue (Boutique du Système) — Foundry v12/v13 */
const MOD = "last-horizon-catalogue";
const { ApplicationV2 } = foundry.applications.api;
const LV_NAMES = ["", "Comptoir", "Étal", "Échoppe", "Boutique", "Maison", "Comptoir stellaire", "Galerie", "Salle des enchères", "Chambre forte", "Catalogue total"];
const TYPE_FR = { skill: "Compétence", title: "Titre", weapon: "Arme", armor: "Armure", vehicle: "Véhicule", companion: "Compagnon", property: "Propriété", item: "Objet" };
const TYPE_ICON = { skill: "icons/svg/book.svg", title: "icons/svg/trophy.svg", weapon: "icons/svg/sword.svg", armor: "icons/svg/shield.svg", vehicle: "icons/svg/anchor.svg", companion: "icons/svg/pawprint.svg", property: "icons/svg/house.svg", item: "icons/svg/item-bag.svg" };

/* ───────────────── Settings ───────────────── */
const MAP_DEFAULT = {
  itemType: "equippableItem",            // type d'Item CSB
  templateName: "",                      // nom du template CSB (_equippableItemTemplate) ; vide = premier trouvé
  keyName: "", keyRang: "rang", keyRarete: "rarete", keyType: "type", keyGold: "gold", keyQuantite: "quantite",
  keyDescription: "description", keyLore: "lore", keyNiveau: "niveau", keyElement: "element", keyCategorie: "", keyRangNum: "",
  actorGoldPath: "system.props.gold", deduct: true
};

class MappingConfig extends FormApplication {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions, { id: "lh-map", title: "Catalogue — Correspondance CSB", template: `modules/${MOD}/templates/mapping.hbs`, width: 560, classes: ["lh-map-form"] }); }
  getData() { return { m: foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping")) }; }
  async _updateObject(_ev, data) { await game.settings.set(MOD, "mapping", foundry.utils.expandObject(data).m); ui.notifications.info("Correspondance CSB enregistrée."); }
}

Hooks.once("init", () => {
  game.settings.register(MOD, "shopLv", { name: "Niveau de la Boutique (1–10)", hint: "Ce que les joueurs peuvent voir et acheter. 1 Comptoir … 10 Catalogue total.", scope: "world", config: true, type: Number, range: { min: 1, max: 10, step: 1 }, default: 1,
    onChange: lv => { app?.frame?.contentWindow?.postMessage({ type: "lh-shoplv", shopLv: lv }, "*"); } });
  game.settings.register(MOD, "playersCanOpen", { name: "Les joueurs peuvent ouvrir le Catalogue", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "playersCanBuy", { name: "Les joueurs peuvent acheter", hint: "Sinon seul le MJ peut créer les objets.", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(MOD, "mapping", { scope: "world", config: false, type: Object, default: MAP_DEFAULT });
  game.settings.registerMenu(MOD, "mappingMenu", { name: "Correspondance des champs CSB", label: "Configurer", hint: "Clés des propriétés Custom System Builder utilisées à l'achat et à l'import.", icon: "fa-solid fa-sliders", type: MappingConfig, restricted: true });
  game.settings.registerMenu(MOD, "importMenu", { name: "Importer le Catalogue en compendium", label: "Importer", hint: "Crée des compendiums d'Items (un par type) à partir des 7 779 entrées.", icon: "fa-solid fa-boxes-stacked", type: ImportDialog, restricted: true });
  game.modules.get(MOD).api = { open: openCatalogue, buy: buyEntry, importCompendium, loadData };
});

/* ───────────────── Fenêtre ───────────────── */
class CatalogueApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = { id: "lh-catalogue", classes: ["lh-frame"], window: { title: "Le Catalogue — Boutique du Système", icon: "fa-solid fa-store", resizable: true, minimizable: true }, position: { width: 1500, height: 900 } };
  async _prepareContext() { return {}; }
  async _renderHTML() {
    const f = document.createElement("iframe"); f.className = "lh-iframe"; f.src = `modules/${MOD}/app/catalogue.html`; this.frame = f; return f;
  }
  _replaceHTML(result, content) { content.replaceChildren(result); }
}
let app = null;
function openCatalogue() { if (!app) app = new CatalogueApp(); app.render({ force: true }); return app; }
function initFrame(win) { win.postMessage({ type: "lh-init", shopLv: game.settings.get(MOD, "shopLv"), isGM: game.user.isGM, hideExport: !game.user.isGM }, "*"); }

window.addEventListener("message", async ev => {
  const m = ev.data || {}; if (!m || typeof m.type !== "string" || !m.type.startsWith("lh-")) return;
  const win = ev.source;
  if (m.type === "lh-ready") initFrame(win);
  else if (m.type === "lh-setlv") { if (game.user.isGM) await game.settings.set(MOD, "shopLv", Math.max(1, Math.min(10, m.shopLv))); else initFrame(win); }
  else if (m.type === "lh-buy") { const r = await buyEntry(m.entry); if (r) win.postMessage({ type: "lh-bought", name: r.item.name, actor: r.actor.name }, "*"); }
});

/* ───────────────── Achat ───────────────── */
function targetActor() {
  const tok = canvas?.tokens?.controlled?.[0]; if (tok?.actor) return tok.actor;
  if (game.user.character) return game.user.character;
  return null;
}
function fmtG(v) { return Math.round(v || 0).toLocaleString("fr-FR") + " G"; }
async function buyEntry(e) {
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanBuy")) return ui.notifications.warn("Les achats sont réservés au MJ.");
  if (e.reqShop > game.settings.get(MOD, "shopLv") && !game.user.isGM) return ui.notifications.warn("Niveau de boutique insuffisant.");
  const actor = targetActor(); if (!actor) return ui.notifications.warn("Sélectionne un token ou assigne-toi un personnage.");
  if (!actor.isOwner) return ui.notifications.warn("Tu ne possèdes pas ce personnage.");
  const M = foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping"));
  const price = e.price || 0;
  // Confirmation
  const ok = await Dialog.confirm({ title: "Boutique du Système", content: `<p><b>${e.n}</b> — rang ${e.rang} · ${e.rar}<br>${e.desc}</p><p>Prix : <b>${fmtG(price)}</b>${M.deduct && price ? ` — débité de <b>${actor.name}</b>` : ""}</p>`, yes: () => true, no: () => false, defaultYes: true });
  if (!ok) return null;
  // Or
  if (M.deduct && price) {
    const cur = Number(foundry.utils.getProperty(actor, M.actorGoldPath));
    if (Number.isFinite(cur)) {
      if (cur < price) { if (!game.user.isGM) return ui.notifications.error(`G insuffisants : ${fmtG(cur)} disponibles.`); ui.notifications.warn(`G insuffisants (${fmtG(cur)}), achat forcé par le MJ.`); }
      await actor.update({ [M.actorGoldPath]: cur - price });
    } else ui.notifications.warn(`Portefeuille introuvable (${M.actorGoldPath}) — objet créé sans débit.`);
  }
  const data = await itemData(e, M);
  const [item] = await actor.createEmbeddedDocuments("Item", [data]);
  ui.notifications.info(`${e.n} ajouté à ${actor.name}.`);
  ChatMessage.create({ speaker: ChatMessage.getSpeaker({ actor }), content: `<div class="lh-chat"><b>◆ Boutique du Système</b><br>${actor.name} acquiert <b>${e.n}</b> (rang ${e.rang} · ${e.rar}) pour ${fmtG(price)}.</div>` });
  return { item, actor };
}

/* Construit les données d'Item (CSB si possible, sinon générique) */
let _tplCache = null;
function findTemplate(M) {
  if (_tplCache !== null) return _tplCache;
  const tpls = game.items.filter(i => i.type === "_equippableItemTemplate");
  _tplCache = (M.templateName ? tpls.find(t => t.name === M.templateName) : tpls[0]) || false;
  return _tplCache;
}
async function itemData(e, M) {
  const lvl = e.lv ? 1 : null;
  const desc = `<p>${e.desc}</p>${e.evo ? `<p><i>Évolution :</i> ${e.evo}</p>` : ""}${e.cond ? `<p><i>Condition :</i> ${e.cond}</p>` : ""}`;
  const base = { name: e.n, img: TYPE_ICON[e.t] || "icons/svg/item-bag.svg", flags: { [MOD]: { id: e.id, t: e.t, cat: e.cat, sub: e.sub, rang: e.rang, rar: e.rar, price: e.price, elem: e.elem, origin: e.origin } } };
  const csb = game.system.id === "custom-system-builder";
  if (csb) {
    const tpl = findTemplate(M);
    const props = {};
    const set = (k, v) => { if (k && v !== undefined && v !== null && v !== "") props[k] = v; };
    set(M.keyName, e.n); set(M.keyRang, e.rang); set(M.keyRarete, e.rar); set(M.keyType, e.sub); set(M.keyCategorie, e.cat);
    set(M.keyGold, e.price || 0); set(M.keyQuantite, 1); set(M.keyDescription, e.desc); set(M.keyLore, e.lore || ""); set(M.keyNiveau, lvl); set(M.keyElement, e.elem || "");
    set(M.keyRangNum, ["F","E","D","C","B","A","S","SS","SSS"].indexOf(e.rang) + 1);
    const sys = { props, description: desc };
    if (tpl) sys.template = tpl.id; else ui.notifications.warn("Aucun template d'objet CSB trouvé : objet créé sans template (à régler dans Correspondance CSB).");
    return { ...base, type: M.itemType || "equippableItem", system: sys };
  }
  const types = Object.keys(game.documentTypes?.Item || CONFIG.Item.typeLabels || {}).filter(t => t !== "base");
  return { ...base, type: types[0] || "base", system: { description: desc } };
}

/* ───────────────── Import compendium ───────────────── */
let _data = null;
async function loadData() { if (!_data) _data = await (await fetch(`modules/${MOD}/data/catalogue.json`)).json(); return _data; }
class ImportDialog extends FormApplication {
  static get defaultOptions() { return foundry.utils.mergeObject(super.defaultOptions, { id: "lh-import", title: "Importer le Catalogue en compendium", template: `modules/${MOD}/templates/import.hbs`, width: 460 }); }
  getData() { return { types: Object.entries(TYPE_FR).map(([k, v]) => ({ k, v })) }; }
  async _updateObject(_ev, data) { const types = Object.entries(data).filter(([k, v]) => v && TYPE_FR[k]).map(([k]) => k); if (!types.length) return ui.notifications.warn("Choisis au moins un type."); await importCompendium(types); }
}
async function importCompendium(types) {
  const D = await loadData(); const M = foundry.utils.mergeObject(foundry.utils.deepClone(MAP_DEFAULT), game.settings.get(MOD, "mapping"));
  for (const t of types) {
    const rows = D.filter(e => e.t === t); const name = `lh-${t}`; const label = `Catalogue — ${TYPE_FR[t]}s`;
    let pack = game.packs.get(`world.${name}`);
    if (!pack) pack = await CompendiumCollection.createCompendium({ label, name, type: "Item", package: "world" });
    await pack.configure({ locked: false });
    const existing = new Set((await pack.getIndex({ fields: ["flags"] })).map(i => i.flags?.[MOD]?.id).filter(Boolean));
    const todo = rows.filter(e => !existing.has(e.id));
    ui.notifications.info(`${label} : ${todo.length} entrées à importer…`);
    const docs = []; for (const e of todo) docs.push(await itemData(e, M));
    for (let i = 0; i < docs.length; i += 200) { await Item.createDocuments(docs.slice(i, i + 200), { pack: pack.collection, keepId: false }); ui.notifications.info(`${label} : ${Math.min(i + 200, docs.length)} / ${docs.length}`); }
    await pack.configure({ locked: true });
  }
  ui.notifications.info("Import terminé.");
}

/* ───────────────── Boutons ───────────────── */
Hooks.on("getSceneControlButtons", controls => {
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanOpen")) return;
  const tool = { name: "lh-catalogue", title: "Le Catalogue — Boutique du Système", icon: "fa-solid fa-store", button: true, order: 98, onChange: () => openCatalogue(), onClick: () => openCatalogue() };
  if (Array.isArray(controls)) { const c = controls.find(c => c.name === "notes") || controls[0]; c.tools.push(tool); }
  else { const c = controls.notes || controls.tokens; if (c) c.tools["lh-catalogue"] = tool; }
});
Hooks.on("renderItemDirectory", (dir, html) => {
  if (!game.user.isGM && !game.settings.get(MOD, "playersCanOpen")) return;
  const root = html instanceof HTMLElement ? html : html[0]; if (root.querySelector(".lh-cat-btn")) return;
  const btn = document.createElement("button"); btn.className = "lh-cat-btn"; btn.innerHTML = '<i class="fa-solid fa-store"></i> Le Catalogue — Boutique du Système'; btn.addEventListener("click", openCatalogue);
  (root.querySelector(".directory-header") || root).appendChild(btn);
});
Hooks.on("updateSetting", s => { if (s.key === `${MOD}.shopLv`) app?.frame?.contentWindow?.postMessage({ type: "lh-shoplv", shopLv: Number(s.value) }, "*"); });
